import { useState, useEffect, useMemo } from "react";
import { Calendar } from "@/components/ui/calendar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Users, Clock, PartyPopper } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { de } from "date-fns/locale";
import { format } from "date-fns";

interface Course {
  id: string;
  title: string;
  trainer: string;
  course_date: string;
  start_time: string;
  end_time: string;
  max_participants: number;
  registered_count: number;
  waitlisted_count: number;
  waitlist_count: number;
  color?: string;
  is_event?: boolean;
  event_price?: number | null;
}

interface AdminCoursesCalendarViewProps {
  onCourseClick: (course: Course) => void;
}

export const AdminCoursesCalendarView = ({ onCourseClick }: AdminCoursesCalendarViewProps) => {
  const [courses, setCourses] = useState<Course[]>([]);
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadCoursesData();
  }, []);

  const loadCoursesData = async () => {
    try {
      setLoading(true);
      
      // Load courses from 3 months ago to 3 months in the future
      const threeMonthsAgo = new Date();
      threeMonthsAgo.setMonth(threeMonthsAgo.getMonth() - 3);
      const threeMonthsLater = new Date();
      threeMonthsLater.setMonth(threeMonthsLater.getMonth() + 3);

      const { data: coursesData, error: coursesError } = await supabase
        .from("courses")
        .select("*, course_registrations(status)")
        .gte("course_date", threeMonthsAgo.toISOString().split('T')[0])
        .lte("course_date", threeMonthsLater.toISOString().split('T')[0])
        .order("course_date", { ascending: true })
        .order("start_time", { ascending: true });

      if (coursesError) throw coursesError;

      // Get all guest registrations in bulk (guard against empty array)
      const courseIds = (coursesData || []).map(c => c.id);
      let guestRegistrations: { course_id: string }[] = [];
      if (courseIds.length > 0) {
        const { data: guestData } = await supabase
          .from("guest_registrations")
          .select("course_id")
          .in("course_id", courseIds)
          .eq("status", "registered");
        guestRegistrations = guestData || [];
      }

      const guestCountMap = new Map<string, number>();
      for (const guest of guestRegistrations) {
        guestCountMap.set(guest.course_id, (guestCountMap.get(guest.course_id) || 0) + 1);
      }

      // Count from joined data — no extra queries
      const coursesWithCounts = (coursesData || []).map((course) => {
        const regs = (course as any).course_registrations || [];
        const memberCount = regs.filter((r: any) => r.status === "registered").length;
        const guestCount = guestCountMap.get(course.id) || 0;
        const registered_count = memberCount + guestCount;
        const waitlist_count = regs.filter((r: any) => r.status === "waitlist").length;

        return {
          ...course,
          registered_count,
          waitlist_count,
          waitlisted_count: waitlist_count,
        };
      });

      setCourses(coursesWithCounts);
    } catch (error) {
      console.error("Error loading courses:", error);
      toast.error("Fehler beim Laden der Kurse");
    } finally {
      setLoading(false);
    }
  };

  const coursesForSelectedDate = useMemo(() => {
    return courses.filter(
      (course) => course.course_date === format(selectedDate, "yyyy-MM-dd")
    );
  }, [courses, selectedDate]);

  const datesWithCourses = useMemo(() => {
    return courses.map((course) => new Date(course.course_date));
  }, [courses]);

  if (loading) {
    return <div className="text-center py-8">Lade Kurse...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-center">
        <Calendar
          mode="single"
          selected={selectedDate}
          onSelect={(date) => date && setSelectedDate(date)}
          locale={de}
          className="rounded-md border"
        />
      </div>

      <div className="space-y-4">
        <h3 className="text-lg font-semibold">
          Kurse am {format(selectedDate, "dd.MM.yyyy", { locale: de })}
        </h3>

        {coursesForSelectedDate.length === 0 ? (
          <p className="text-muted-foreground text-center py-8">
            Keine Kurse an diesem Tag
          </p>
        ) : (
          <div className="grid gap-4">
            {coursesForSelectedDate.map((course) => (
              <Card
                key={course.id}
                className="cursor-pointer hover:shadow-lg transition-shadow"
                onClick={() => onCourseClick(course)}
                style={{ borderLeft: `4px solid ${course.color || '#f3f4f6'}` }}
              >
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <CardTitle className="text-lg">{course.title}</CardTitle>
                      {course.is_event && (
                        <Badge className="bg-primary text-primary-foreground">
                          <PartyPopper className="h-3 w-3 mr-1" />
                          Event
                        </Badge>
                      )}
                    </div>
                    <div className="flex gap-2 items-center">
                      <Badge variant="outline" className="flex items-center gap-1">
                        <Users className="h-3 w-3" />
                        {course.registered_count}/{course.max_participants}
                      </Badge>
                      {course.waitlist_count > 0 && (
                        <Badge variant="secondary">
                          Warteliste: {course.waitlist_count}
                        </Badge>
                      )}
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-4 text-sm text-muted-foreground">
                    <div className="flex items-center gap-1">
                      <Clock className="h-4 w-4" />
                      {course.start_time.slice(0, 5)} - {course.end_time.slice(0, 5)}
                    </div>
                    <div>Trainer: {course.trainer}</div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
