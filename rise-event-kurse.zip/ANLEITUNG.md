# Event-Kurse – Upload-Anleitung

Dieses Paket enthält alle 14 Dateien für das Event-Feature. Die Ordnerstruktur im Zip entspricht exakt der Struktur im GitHub-Repository (`rise-workout-buddy`) – jede Datei muss an genau diesen Pfad.

## Was ist drin?

| Datei | Was passiert |
|---|---|
| `supabase/migrations/20260811120000_event_courses.sql` | **NEU** – neue Spalten `is_event` + `event_price`, Anpassung der Buchungs-/Limit-Funktionen in der Datenbank |
| `supabase/functions/book-guest-training/index.ts` | Externe Event-Anmeldung (Buchungsart `event`, keine E-Mail, Preis aus DB) |
| `supabase/functions/check-course-attendance/index.ts` | Events werden nicht mehr automatisch wegen „zu wenig Teilnehmer" abgesagt |
| `src/components/CourseTemplateManager.tsx` | Admin: Event-Schalter + Preisfeld bei Vorlagen und beim Kurs-Bearbeiten |
| `src/components/AdminCoursesCalendarView.tsx` | Admin-Kalender: Event-Badge |
| `src/components/AdminWidgetBookings.tsx` | Admin: Event-Buchungen in der Widget-Buchungsliste (Badge, Filter, Zähler) |
| `src/components/CourseBooking.tsx` | Mitglieder-App: Event-Badge + Hinweis „kein Limit / kein Credit", Event-Gäste in Teilnehmerliste |
| `src/components/CoursesCalendarView.tsx` | Mitglieder-Kalender: Event-Badge |
| `src/components/CourseParticipantsList.tsx`, `src/components/DayCourseDialog.tsx`, `src/components/UpcomingClassReservation.tsx` | Event-Gäste korrekt als „Event-Gast" angezeigt |
| `src/pages/EmbedKursplan.tsx` | Website-Kursplan: Events sichtbar + Anmeldeformular für Externe (Name, E-Mail, Bestätigung → Erfolgsanzeige) |
| `src/components/EmbedWeekTableView.tsx` | Website-Wochenansicht: Event-Badge |
| `src/integrations/supabase/types.ts` | TypeScript-Typen für die neuen Spalten |

## So bringst du es ins Repo (GitHub-Web-Oberfläche)

1. Zip entpacken.
2. Im GitHub-Repo am besten einen neuen Branch anlegen (z. B. `event-kurse`).
3. Die Dateien per „Add file → Upload files" in die **jeweiligen Ordner** hochladen (GitHub ersetzt bestehende Dateien mit gleichem Namen automatisch). Du kannst auch die entpackten Ordner `src` und `supabase` komplett per Drag & Drop auf die Repo-Startseite ziehen – GitHub übernimmt dann die Pfade automatisch.
4. Commit erstellen (z. B. „Event-Kurse: offen für alle + externe Anmeldung über Website-Kursplan") und ggf. Pull Request mergen.
5. Lovable synct die Änderungen automatisch aus GitHub.

## Wichtig: Datenbank-Migration

Die Datei unter `supabase/migrations/` muss einmal auf eurer Supabase-Datenbank ausgeführt werden. Bei Lovable passiert das normalerweise automatisch beim Sync; falls nicht, den Inhalt der Datei im Supabase SQL-Editor ausführen. **Ohne die Migration funktioniert das Feature nicht** (die App erwartet die neuen Spalten). Die beiden Edge Functions werden beim Deploy automatisch aktualisiert.

## So legst du ein Event an

1. Admin → Kursverwaltung → Vorlagen: neue Vorlage anlegen, Schalter **„Event-Kurs (offen für alle)"** aktivieren, optional **Preis für Externe** eintragen (leer = kostenlos).
2. Terminplanung: Termin(e) aus der Vorlage generieren wie gewohnt.
3. Alternativ: bestehenden einzelnen Kurs unter „Kurse bearbeiten" öffnen und dort den Event-Schalter setzen.
4. Das Event erscheint mit Badge in der App und im Website-Kursplan. Externe klicken es dort an → „Zum Event anmelden" → Name + E-Mail + Bestätigung → Erfolgsanzeige.

## Was das Feature macht

- **Premium/Wellpass:** buchen wie gewohnt.
- **Basic:** Event zählt nicht auf die 2 Trainings/Woche (weder Abzug noch Blockierung).
- **10er Karte:** kein Credit-Abzug, bei Storno auch keine fälschliche Gutschrift.
- **Externe:** Anmeldung über den Website-Kursplan, ohne Konto, nur Erfolgsanzeige (keine E-Mail). Bei gesetztem Preis wird „Zahlung vor Ort: X €" angezeigt.
- **Voll:** Mitglieder kommen auf die Warteliste, Externe sehen „ausgebucht".
- Events werden nie automatisch wegen zu weniger Teilnehmer abgesagt.

## Kurz testen nach dem Deploy

1. Event-Vorlage (kostenlos + eine mit Preis) anlegen, Termin generieren → Badge in Admin/App/Website sichtbar.
2. Als Basic mit 2 gebuchten Kursen das Event buchen → klappt, Anzeige bleibt 2/2.
3. Als 10er Karte buchen + stornieren → Credits unverändert.
4. Website-Kursplan (Inkognito): Event anmelden → Erfolgsanzeige; gleiche E-Mail nochmal → Fehlermeldung; volles Event → „ausgebucht".
5. Einen regulären Kurs buchen/stornieren → Abzug/Erstattung wie bisher.
