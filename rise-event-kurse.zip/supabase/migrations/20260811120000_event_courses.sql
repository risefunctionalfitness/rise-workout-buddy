-- =====================================================================
-- EVENT COURSES
-- A special course type that is open to everyone:
--   * Premium / Wellpass members: book as usual
--   * Basic members: booking does NOT count towards the 2 trainings/week
--   * 10er Karte: booking does NOT consume a credit (and cancelling
--     does NOT refund one)
--   * External guests: can register via a public link with name + email
--     (guest_registrations with booking_type = 'event')
-- Capacity checks and the member waitlist keep working unchanged.
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1. New columns on course_templates and courses
--    event_price: NULL = free for external guests,
--    otherwise price in EUR to be paid on site.
-- ---------------------------------------------------------------------
ALTER TABLE public.course_templates
  ADD COLUMN IF NOT EXISTS is_event boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS event_price numeric NULL;

ALTER TABLE public.courses
  ADD COLUMN IF NOT EXISTS is_event boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS event_price numeric NULL;

-- ---------------------------------------------------------------------
-- 2. Allow 'event' as a guest booking type
-- ---------------------------------------------------------------------
ALTER TABLE public.guest_registrations
  DROP CONSTRAINT IF EXISTS guest_registrations_booking_type_check;

ALTER TABLE public.guest_registrations
  ADD CONSTRAINT guest_registrations_booking_type_check
  CHECK (booking_type IN ('drop_in', 'probetraining', 'event'));

-- ---------------------------------------------------------------------
-- 3. can_user_register_for_course:
--    * Event courses: everyone may register (no membership checks)
--    * Basic weekly count: event bookings no longer block the
--      2 regular trainings per week
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.can_user_register_for_course(user_id_param uuid, course_id_param uuid)
 RETURNS boolean
 LANGUAGE plpgsql
 SECURITY DEFINER
AS $function$
DECLARE
    user_role TEXT;
    user_membership_type TEXT;
    weekly_count INTEGER;
    user_credits INTEGER;
    course_date_val DATE;
    course_title_val TEXT;
    week_start DATE;
    v_max_participants INTEGER;
    v_total_registered INTEGER;
    v_is_event BOOLEAN;
BEGIN
    -- Get user role and membership type
    SELECT ur.role::TEXT, p.membership_type
    INTO user_role, user_membership_type
    FROM public.user_roles ur
    JOIN public.profiles p ON ur.user_id = p.user_id
    WHERE ur.user_id = user_id_param
    LIMIT 1;

    -- Get course date, title, max_participants and event flag
    SELECT c.course_date, c.title, c.max_participants, COALESCE(c.is_event, false)
    INTO course_date_val, course_title_val, v_max_participants, v_is_event
    FROM public.courses c
    WHERE c.id = course_id_param;

    -- Event courses are open to everyone: no limit or credit checks
    IF v_is_event THEN
        RETURN TRUE;
    END IF;

    -- Admin and trainers can always register
    IF user_role IN ('admin', 'trainer') THEN
        RETURN TRUE;
    END IF;

    -- Check total capacity including guest registrations
    SELECT
        (SELECT COUNT(*) FROM public.course_registrations WHERE course_id = course_id_param AND status = 'registered')
        + (SELECT COUNT(*) FROM public.guest_registrations WHERE course_id = course_id_param AND status = 'registered')
    INTO v_total_registered;

    -- Check based on membership type
    IF user_membership_type = 'Basic Member' THEN
        -- Calculate week start (Monday)
        week_start := course_date_val - ((EXTRACT(DOW FROM course_date_val)::INTEGER + 6) % 7);

        -- Count registrations for the current week (event courses excluded)
        SELECT COUNT(*) INTO weekly_count
        FROM public.course_registrations cr
        JOIN public.courses c ON cr.course_id = c.id
        WHERE cr.user_id = user_id_param
          AND cr.status IN ('registered', 'waitlist')
          AND c.course_date >= week_start
          AND c.course_date < week_start + 7
          AND COALESCE(c.is_event, false) = false;

        RETURN weekly_count < 2;

    ELSIF user_membership_type = '10er Karte' THEN
        -- Read credits from membership_credits table
        SELECT credits_remaining INTO user_credits
        FROM public.membership_credits
        WHERE user_id = user_id_param;

        RETURN COALESCE(user_credits, 0) > 0;
    ELSE
        -- All other membership types can register freely
        RETURN TRUE;
    END IF;
END;
$function$;

-- ---------------------------------------------------------------------
-- 4. handle_membership_limits:
--    Event courses never touch credits or the weekly counter --
--    neither on booking, nor on reactivation, nor on waitlist
--    promotion, nor on cancellation (otherwise a 10er-Karte member
--    would wrongly GAIN a credit when cancelling an event booking).
--    Body is based on the latest version (20260423093545) with the
--    event short-circuit added at the top -- all existing branches
--    (incl. waitlist promotion, admin_cancelled/rebooked handling and
--    the GREATEST(0, ...) guards) are preserved unchanged.
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.handle_membership_limits()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    user_membership_type TEXT;
    week_start DATE;
    v_is_event BOOLEAN := false;
BEGIN
    -- 0) Event-Kurse: weder Credits noch Wochenlimit anfassen
    IF TG_OP IN ('INSERT', 'UPDATE') THEN
        SELECT COALESCE(is_event, false) INTO v_is_event
        FROM public.courses
        WHERE id = NEW.course_id;

        IF v_is_event THEN
            RETURN NEW;
        END IF;
    END IF;

    -- 1) INSERT: nur 'registered' zieht ab
    IF TG_OP = 'INSERT' AND NEW.status IN ('registered', 'waitlisted') THEN
        SELECT membership_type INTO user_membership_type
        FROM public.profiles WHERE user_id = NEW.user_id;

        IF user_membership_type = '10er Karte' THEN
            UPDATE public.membership_credits
            SET credits_remaining = GREATEST(0, credits_remaining - 1),
                updated_at = now()
            WHERE user_id = NEW.user_id;
        END IF;

        IF user_membership_type = 'Basic Member' THEN
            SELECT course_date - EXTRACT(DOW FROM course_date)::INTEGER + 1
            INTO week_start FROM public.courses WHERE id = NEW.course_id;

            INSERT INTO public.weekly_course_limits (user_id, week_start_date, registrations_count)
            VALUES (NEW.user_id, week_start, 1)
            ON CONFLICT (user_id, week_start_date)
            DO UPDATE SET registrations_count = public.weekly_course_limits.registrations_count + 1,
                          updated_at = now();
        END IF;
        RETURN NEW;
    END IF;

    -- 2) Re-Aktivierung aus Storno-Status
    IF TG_OP = 'UPDATE'
       AND OLD.status IN ('cancelled', 'waitlist_cancelled', 'admin_cancelled', 'rebooked')
       AND NEW.status IN ('registered', 'waitlisted') THEN
        SELECT membership_type INTO user_membership_type
        FROM public.profiles WHERE user_id = NEW.user_id;

        IF user_membership_type = '10er Karte' THEN
            UPDATE public.membership_credits
            SET credits_remaining = GREATEST(0, credits_remaining - 1),
                updated_at = now()
            WHERE user_id = NEW.user_id;
        END IF;

        IF user_membership_type = 'Basic Member' THEN
            SELECT course_date - EXTRACT(DOW FROM course_date)::INTEGER + 1
            INTO week_start FROM public.courses WHERE id = NEW.course_id;

            INSERT INTO public.weekly_course_limits (user_id, week_start_date, registrations_count)
            VALUES (NEW.user_id, week_start, 1)
            ON CONFLICT (user_id, week_start_date)
            DO UPDATE SET registrations_count = public.weekly_course_limits.registrations_count + 1,
                          updated_at = now();
        END IF;
        RETURN NEW;
    END IF;

    -- 3) Promotion von Warteliste -> registriert
    IF TG_OP = 'UPDATE'
       AND OLD.status IN ('waitlist', 'waitlisted')
       AND NEW.status = 'registered' THEN
        SELECT membership_type INTO user_membership_type
        FROM public.profiles WHERE user_id = NEW.user_id;

        IF user_membership_type = '10er Karte' THEN
            UPDATE public.membership_credits
            SET credits_remaining = GREATEST(0, credits_remaining - 1),
                updated_at = now()
            WHERE user_id = NEW.user_id;
        END IF;

        IF user_membership_type = 'Basic Member' THEN
            SELECT course_date - EXTRACT(DOW FROM course_date)::INTEGER + 1
            INTO week_start FROM public.courses WHERE id = NEW.course_id;

            INSERT INTO public.weekly_course_limits (user_id, week_start_date, registrations_count)
            VALUES (NEW.user_id, week_start, 1)
            ON CONFLICT (user_id, week_start_date)
            DO UPDATE SET registrations_count = public.weekly_course_limits.registrations_count + 1,
                          updated_at = now();
        END IF;
        RETURN NEW;
    END IF;

    -- 4) Storno aus 'registered' -> Refund
    IF TG_OP = 'UPDATE'
       AND OLD.status = 'registered'
       AND NEW.status IN ('cancelled', 'waitlist_cancelled', 'admin_cancelled', 'rebooked') THEN
        SELECT membership_type INTO user_membership_type
        FROM public.profiles WHERE user_id = NEW.user_id;

        IF user_membership_type = '10er Karte' THEN
            UPDATE public.membership_credits
            SET credits_remaining = credits_remaining + 1,
                updated_at = now()
            WHERE user_id = NEW.user_id;
        END IF;

        IF user_membership_type = 'Basic Member' THEN
            SELECT course_date - EXTRACT(DOW FROM course_date)::INTEGER + 1
            INTO week_start FROM public.courses WHERE id = NEW.course_id;

            UPDATE public.weekly_course_limits
            SET registrations_count = GREATEST(0, registrations_count - 1),
                updated_at = now()
            WHERE user_id = NEW.user_id AND week_start_date = week_start;
        END IF;
        RETURN NEW;
    END IF;

    RETURN NEW;
END;
$$;

-- ---------------------------------------------------------------------
-- 5. generate_courses_from_template (legacy RPC):
--    copy is_event / event_price from the template so event courses
--    generated through this RPC keep their event settings.
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION generate_courses_from_template(
  template_id_param UUID,
  start_date_param DATE,
  end_date_param DATE
) RETURNS TABLE(
  course_id UUID,
  course_date DATE,
  start_time TIME,
  end_time TIME
) AS $$
DECLARE
  template_record RECORD;
  iter_date DATE;
  start_time_calc TIME;
  end_time_calc TIME;
  new_course_id UUID;
BEGIN
  -- Get template details
  SELECT * INTO template_record
  FROM course_templates
  WHERE id = template_id_param;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Template not found';
  END IF;

  -- Generate courses for each day in the date range
  iter_date := start_date_param;
  WHILE iter_date <= end_date_param LOOP
    -- For now, create courses at 18:00 (can be customized later)
    start_time_calc := '18:00:00'::TIME;
    end_time_calc := start_time_calc + (template_record.duration_minutes || ' minutes')::INTERVAL;

    -- Insert the course
    INSERT INTO courses (
      template_id,
      title,
      trainer,
      strength_exercise,
      course_date,
      start_time,
      end_time,
      max_participants,
      registration_deadline_minutes,
      duration_minutes,
      is_event,
      event_price
    ) VALUES (
      template_id_param,
      template_record.title,
      template_record.trainer,
      template_record.strength_exercise,
      iter_date,
      start_time_calc,
      end_time_calc,
      template_record.max_participants,
      template_record.registration_deadline_minutes,
      template_record.duration_minutes,
      COALESCE(template_record.is_event, false),
      CASE WHEN COALESCE(template_record.is_event, false) THEN template_record.event_price ELSE NULL END
    ) RETURNING id INTO new_course_id;

    -- Return the generated course info
    course_id := new_course_id;
    course_date := iter_date;
    start_time := start_time_calc;
    end_time := end_time_calc;
    RETURN NEXT;

    iter_date := iter_date + INTERVAL '1 day';
  END LOOP;

  RETURN;
END;
$$ LANGUAGE plpgsql;

-- ---------------------------------------------------------------------
-- 6. get_weekly_registrations_count:
--    Event bookings are excluded, so the "X/2" display for Basic
--    members stays correct automatically.
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.get_weekly_registrations_count(user_id_param uuid, check_date date DEFAULT CURRENT_DATE)
RETURNS integer
LANGUAGE plpgsql
STABLE SECURITY DEFINER
SET search_path TO ''
AS $$
DECLARE
    week_start DATE;
    reg_count INTEGER;
BEGIN
    -- Calculate start of week (Monday)
    week_start := check_date - EXTRACT(DOW FROM check_date)::INTEGER + 1;

    -- Count non-cancelled registrations in the current week (events excluded)
    SELECT COUNT(*) INTO reg_count
    FROM public.course_registrations cr
    JOIN public.courses c ON cr.course_id = c.id
    WHERE cr.user_id = user_id_param
      AND cr.status IN ('registered', 'waitlisted')
      AND c.course_date >= week_start
      AND c.course_date < week_start + INTERVAL '7 days'
      AND COALESCE(c.is_event, false) = false;

    RETURN COALESCE(reg_count, 0);
END;
$$;
